import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from geometry_msgs.msg import Point
from visualization_msgs.msg import Marker
import numpy as np

def default_motor_positions():
    L = 0.58
    return np.array([
        [0, 0, L],
        [0, L, L],
        [L, L, L],
        [L, 0, L],
        [0, 0, 0],
        [0, L, 0],
        [L, L, 0],
        [L, 0, 0],
    ])

def get_cube_edges(points):
    edges = [
        (0,1), (1,2), (2,3), (3,0),  # Top face
        (4,5), (5,6), (6,7), (7,4),  # Bottom face
        (0,4), (1,5), (2,6), (3,7)   # Vertical edges
    ]
    marker = Marker()
    marker.header.frame_id = 'world'
    marker.type = Marker.LINE_LIST
    marker.action = Marker.ADD
    marker.scale.x = 0.002
    marker.color.r = 0.0
    marker.color.g = 1.0
    marker.color.b = 0.0
    marker.color.a = 1.0
    marker.lifetime.sec = 0
    marker.points = []
    for i1, i2 in edges:
        p1 = Point(x=points[i1][0], y=points[i1][1], z=points[i1][2])
        p2 = Point(x=points[i2][0], y=points[i2][1], z=points[i2][2])
        marker.points.append(p1)
        marker.points.append(p2)
    return marker

class CableVisualizer(Node):
    def __init__(self):
        super().__init__('cable_marker_node')
        self.motors = default_motor_positions()
        self.ee_points = np.zeros((8, 3))  # To be updated from ik_node

        self.cable_pub = self.create_publisher(Marker, 'cable_markers', 10)
        self.frame_pub = self.create_publisher(Marker, 'cube_frame_marker', 10)
        self.ee_box_pub = self.create_publisher(Marker, 'ee_cube_marker', 10)

        self.subscription = self.create_subscription(
            Float64MultiArray,
            'ee_attach_points',
            self.ee_callback,
            10
        )

        self.frame_timer = self.create_timer(1.0, self.publish_cube_frame)


    def ee_callback(self, msg: Float64MultiArray):
        data = np.array(msg.data).reshape((8, 3))
        self.ee_points = data
        self.publish_cables(self.ee_points)
        self.publish_ee_box(self.ee_points)

    def publish_cables(self, ee_points):
        marker = Marker()
        marker.header.frame_id = 'world'
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "cables"
        marker.id = 0
        marker.type = Marker.LINE_LIST
        marker.action = Marker.ADD
        marker.scale.x = 0.003
        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0
        marker.color.a = 1.0
        marker.lifetime.sec = 0
        marker.points = []

        for i in range(8):
            p1 = Point(x=self.motors[i][0], y=self.motors[i][1], z=self.motors[i][2])
            p2 = Point(x=ee_points[i][0], y=ee_points[i][1], z=ee_points[i][2])
            marker.points.append(p1)
            marker.points.append(p2)

        self.cable_pub.publish(marker)

    def publish_cube_frame(self):
        marker = get_cube_edges(self.motors)
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "cube_frame"
        marker.id = 1
        marker.color.r = 0.0
        marker.color.g = 0.5
        marker.color.b = 1.0
        marker.color.a = 1.0

        self.frame_pub.publish(marker)

    def publish_ee_box(self, ee_points):
        marker = get_cube_edges(ee_points)
        marker.ns = "ee_box"
        marker.id = 2
        marker.color.r = 1.0
        marker.color.g = 1.0
        marker.color.b = 0.0
        marker.color.a = 1.0
        self.ee_box_pub.publish(marker)

def main(args=None):
    rclpy.init(args=args)
    node = CableVisualizer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
