import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose
from collections import deque
import csv
import os

LOG_FILE = "ee_pose_log.csv"
MAX_HISTORY = 10

class EEPositionLogger(Node):
    def __init__(self):
        super().__init__('ee_position_logger')

        self.pose_history = deque(maxlen=MAX_HISTORY)

        self.subscription = self.create_subscription(
            Pose,
            'actual_ee_pose',  # Replace with your topic name
            self.pose_callback,
            10
        )
   
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

        # Truncate or create the log file on startup
        with open(LOG_FILE, 'w') as f:
            writer = csv.writer(f)
            writer.writerow(['sec', 'nanosec', 'x', 'y', 'z', 'qx', 'qy', 'qz', 'qw'])

    def pose_callback(self, msg: Pose):
        timestamp = self.get_clock().now().to_msg()
        self.pose_history.append((timestamp, msg))

        with open(LOG_FILE, 'a') as f:
            writer = csv.writer(f)
            writer.writerow([
                timestamp.sec, timestamp.nanosec,
                msg.position.x, msg.position.y, msg.position.z,
                msg.orientation.x, msg.orientation.y,
                msg.orientation.z, msg.orientation.w
            ])

        self.get_logger().info(f"Logged EE Pose at ({msg.position.x:.3f}, {msg.position.y:.3f}, {msg.position.z:.3f})")

    def get_latest_pose(self):
        return self.pose_history[-1] if self.pose_history else None

def main(args=None):
    rclpy.init(args=args)
    node = EEPositionLogger()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
