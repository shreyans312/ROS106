import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

class EncoderReader(Node):
    def __init__(self):
        super().__init__('encoder_reader_node')

        self.encoder_ticks = [0] * 8  # Replace with actual encoder interface
        self.ticks_per_rev = 1024     # HS S32L typical
        self.drum_radius = 0.01       # In meters
        self.prev_ticks = [0] * 8

        self.publisher = self.create_publisher(Float64MultiArray, 'actual_cable_lengths', 10)
        self.timer = self.create_timer(0.05, self.read_encoders)

    def read_encoders(self):
        # Replace this with real GPIO read logic
        # For now simulate incremental ticks
        self.encoder_ticks = [tick + 1 for tick in self.encoder_ticks]

        lengths = [
            2 * 3.1416 * self.drum_radius * (tick / self.ticks_per_rev)
            for tick in self.encoder_ticks
        ]

        msg = Float64MultiArray(data=lengths)
        self.publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = EncoderReader()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()