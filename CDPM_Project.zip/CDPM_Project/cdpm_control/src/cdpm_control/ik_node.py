import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose
from std_msgs.msg import Float64MultiArray
from cdpm_control.utils import compute_cable_lengths, default_geometry
import numpy as np

class InverseKinematicsNode(Node):
    def __init__(self):
        super().__init__('inverse_kinematics_node')
        self.subscription = self.create_subscription(Pose, 'desired_pose', self.pose_callback, 10)
        self.length_pub = self.create_publisher(Float64MultiArray, 'cable_lengths', 10)
        self.point_pub = self.create_publisher(Float64MultiArray, 'ee_attach_points', 10)

        # Get motor and EE geometry
        self.M, self.E_local = default_geometry()

    def quaternion_to_rotation_matrix(self, q):
        x, y, z, w = q
        R = np.array([
            [1 - 2*y**2 - 2*z**2,   2*x*y - 2*z*w,       2*x*z + 2*y*w],
            [2*x*y + 2*z*w,         1 - 2*x**2 - 2*z**2, 2*y*z - 2*x*w],
            [2*x*z - 2*y*w,         2*y*z + 2*x*w,       1 - 2*x**2 - 2*y**2]
        ])
        return R
    
    def pose_callback(self, msg):
        p = np.array([msg.position.x, msg.position.y, msg.position.z])
        q = [msg.orientation.x, msg.orientation.y, msg.orientation.z, msg.orientation.w]
        R = self.quaternion_to_rotation_matrix(q)
        E_global = p + (R @ self.E_local.T).T
        lengths = compute_cable_lengths(p, R, self.E_local, self.M)
        self.get_logger().info(f"Lengths: {np.round(lengths, 4)}")
        self.length_pub.publish(Float64MultiArray(data=lengths.tolist()))
        flat_pts = E_global.flatten().tolist()
        self.point_pub.publish(Float64MultiArray(data=flat_pts))

def main(args=None):
    rclpy.init(args=args)
    node = InverseKinematicsNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
