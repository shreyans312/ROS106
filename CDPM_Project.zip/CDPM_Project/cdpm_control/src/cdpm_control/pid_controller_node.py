import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose
from std_msgs.msg import Float64MultiArray
import numpy as np
import csv
from datetime import datetime
from collections import deque
from scipy.optimize import nnls

class PIDController(Node):
    def __init__(self):
        super().__init__('pid_controller_node')

        self.declare_parameter('Kp', [1.0, 1.0, 1.0])
        self.declare_parameter('Ki', [0.0, 0.0, 0.0])
        self.declare_parameter('Kd', [0.1, 0.1, 0.1])
        self.declare_parameter('dt', 0.1)
        self.declare_parameter('max_integral', [5.0, 5.0, 5.0])
        self.declare_parameter('max_output', [10.0, 10.0, 10.0])
        self.declare_parameter('derivative_filter_alpha', 0.9)
        self.declare_parameter('velocity_scale', 1.0)
        self.declare_parameter('steps_per_rev', 200)
        self.declare_parameter('pulley_radius_mm', 10.0)

        self.Kp = np.array(self.get_parameter('Kp').value)
        self.Ki = np.array(self.get_parameter('Ki').value)
        self.Kd = np.array(self.get_parameter('Kd').value)
        self.dt = self.get_parameter('dt').value
        self.max_integral = np.array(self.get_parameter('max_integral').value)
        self.max_output = np.array(self.get_parameter('max_output').value)
        self.alpha = self.get_parameter('derivative_filter_alpha').value
        self.velocity_scale = self.get_parameter('velocity_scale').value
        self.steps_per_rev = self.get_parameter('steps_per_rev').value
        self.pulley_radius_mm = self.get_parameter('pulley_radius_mm').value
        self.mm_per_step = 2 * np.pi * self.pulley_radius_mm / self.steps_per_rev

        self.anchor_points = self.get_anchor_points()
        self.num_cables = self.anchor_points.shape[0]

        self.integral = np.zeros(3)
        self.prev_error = np.zeros(3)
        self.filtered_derivative = np.zeros(3)

        self.desired_pose = None
        self.actual_pose = None

        self.cmd_pub = self.create_publisher(Float64MultiArray, 'motor_command', 10)

        self.subscription1 = self.create_subscription(Pose, 'desired_pose', self.desired_cb, 10)
        self.subscription2 = self.create_subscription(Pose, 'actual_ee_pose', self.actual_cb, 10)

        self.timer = self.create_timer(self.dt, self.control_loop)

        self.log_file = "pid_log.csv"

        self.log_buffer = deque(maxlen=20)
        with open(self.log_file, 'w') as f:
            writer = csv.writer(f)
            writer.writerow(['time', 'ex', 'ey', 'ez', 'fx', 'fy', 'fz'] + [f'step_rate_{i}' for i in range(self.num_cables)])

    def get_anchor_points(self):
        return np.array([
            [0, 0, 1000], [1000, 0, 1000], [1000, 1000, 1000], [0, 1000, 1000],
            [0, 0, 0], [1000, 0, 0], [1000, 1000, 0], [0, 1000, 0]
        ])
    
    def desired_cb(self, msg):
        self.desired_pose = np.array([
            msg.position.x,
            msg.position.y,
            msg.position.z
        ])

    def actual_cb(self, msg):
        self.actual_pose = np.array([
            msg.position.x,
            msg.position.y,
            msg.position.z
        ])

    def compute_jacobian_transpose(self, ee_pos):
        cable_vectors = self.anchor_points - ee_pos
        norms = np.linalg.norm(cable_vectors, axis=1).reshape(-1, 1) + 1e-6
        unit_vectors = cable_vectors / norms
        return unit_vectors.T
    
    def control_loop(self):
        if self.desired_pose is None or self.actual_pose is None:
            return

        error = self.desired_pose - self.actual_pose
        if np.any(np.isnan(error)) or np.any(np.abs(error) > 1e3):
            self.get_logger().warn("Invalid error detected; skipping control update.")
            return
        
        self.integral += error * self.dt
        self.integral = np.clip(self.integral, -self.max_integral, self.max_integral)

        raw_derivative = (error - self.prev_error) / self.dt
        self.filtered_derivative = self.alpha * self.filtered_derivative + (1 - self.alpha) * raw_derivative

        f_desired = self.Kp * error + self.Ki * self.integral + self.Kd * self.filtered_derivative

        J_T = self.compute_jacobian_transpose(self.actual_pose)
        tau, _ = nnls(J_T.T, f_desired)

        cable_velocities = self.velocity_scale * tau
        step_rates = cable_velocities / self.mm_per_step

        self.prev_error = error

        self.cmd_pub.publish(Float64MultiArray(data=step_rates.tolist()))
        self.get_logger().info(f"Tension: {tau}, Steps/sec: {step_rates}")

        current_time = datetime.now().isoformat()
        self.log_buffer.append([current_time, *error, *f_desired, *step_rates])
        with open(self.log_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['time', 'ex', 'ey', 'ez', 'fx', 'fy', 'fz'] + [f'step_rate_{i}' for i in range(self.num_cables)])
            writer.writerows(self.log_buffer)

def main(args=None):
    rclpy.init(args=args)
    node = PIDController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
