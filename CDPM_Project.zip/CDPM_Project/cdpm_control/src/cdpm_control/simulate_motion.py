import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose
import numpy as np
from scipy.spatial.transform import Rotation as R

class PosePublisher(Node):
    def __init__(self):
        super().__init__('pose_publisher')
        self.publisher = self.create_publisher(Pose, 'desired_pose', 10)
        self.timer = self.create_timer(0.1, self.publish_pose)

        self.t = 0.0
        self.motion_index = 0
        self.max_t = 2 * np.pi
        self.center = 0.29
        self.r = 0.05

        # Motion types
        self.motions = [
            self.circular_motion,
            self.diagonal_line,
            self.horizontal_line,
            self.vertical_line,
            self.feasible_rotating_diagonal  # Rotation motion
        ]

    def publish_pose(self):
        pose = self.motions[self.motion_index]()
        self.publisher.publish(pose)

        self.get_logger().info(
            f"Motion {self.motion_index}: Position=({pose.position.x:.3f}, {pose.position.y:.3f}, {pose.position.z:.3f}), "
            f"Orientation=({pose.orientation.x:.2f}, {pose.orientation.y:.2f}, {pose.orientation.z:.2f}, {pose.orientation.w:.2f})"
        )

        self.t += 0.1

        if self.t > self.max_t:
            self.t = 0.0
            self.motion_index = (self.motion_index + 1) % len(self.motions)

    def make_quaternion_from_axis_angle(self, axis, angle):
        r = R.from_rotvec(angle * np.array(axis))
        q = r.as_quat()  # returns [x, y, z, w]
        return q

    def circular_motion(self):
        pose = Pose()
        pose.position.x = self.center + self.r * np.cos(self.t)
        pose.position.y = self.center + self.r * np.sin(self.t)
        pose.position.z = self.center
        pose.orientation.w = 1.0
        return pose

    def diagonal_line(self):
        pose = Pose()
        pose.position.x = 0.05 + (0.48 * self.t / self.max_t)
        pose.position.y = 0.05 + (0.48 * self.t / self.max_t)
        pose.position.z = 0.05 + (0.48 * self.t / self.max_t)
        pose.orientation.w = 1.0
        return pose

    def horizontal_line(self):
        pose = Pose()
        pose.position.x = 0.05 + (0.48 * self.t / self.max_t)
        pose.position.y = self.center
        pose.position.z = self.center
        pose.orientation.w = 1.0
        return pose

    def vertical_line(self):
        pose = Pose()
        pose.position.x = self.center
        pose.position.y = self.center
        pose.position.z = 0.05 + (0.48 * self.t / self.max_t)
        pose.orientation.w = 1.0
        return pose

    def feasible_rotating_diagonal(self):
        pose = Pose()
        # Move diagonally from one corner to the other
        pose.position.x = 0.05 + (0.48 * self.t / self.max_t)
        pose.position.y = 0.05 + (0.48 * self.t / self.max_t)
        pose.position.z = 0.05 + (0.48 * self.t / self.max_t)

        # Small rotation about Z (yaw), oscillating between -10° to 10°
        angle = np.deg2rad(30) * np.sin(self.t)
        axis = [0, 0, 1]

        q = self.make_quaternion_from_axis_angle(axis, angle)
        pose.orientation.x = q[0]
        pose.orientation.y = q[1]
        pose.orientation.z = q[2]
        pose.orientation.w = q[3]

        return pose

def main(args=None):
    rclpy.init(args=args)
    node = PosePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
