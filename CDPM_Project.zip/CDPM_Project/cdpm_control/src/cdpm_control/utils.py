import numpy as np

def compute_cable_lengths(p, R, E_local, M):
    # E_global = p + R @ E_local.T (then transpose to shape [8, 3])
    E_global = p + (R @ E_local.T).T
    cable_vectors = E_global - M
    lengths = np.linalg.norm(cable_vectors, axis=1)
    return lengths

def default_geometry():
    # All units in meters
    L = 0.58     # Frame length
    b = 0.05     # EE size
    b2 = b / 2.0

    # Motor positions
    motors = np.array([
        [0, 0, L],     # top-front-left
        [0, L, L],     # top-back-left
        [L, L, L],     # top-back-right
        [L, 0, L],     # top-front-right
        [0, 0, 0],     # bottom-front-left
        [0, L, 0],     # bottom-back-left
        [L, L, 0],     # bottom-back-right
        [L, 0, 0],     # bottom-front-right
    ])

    # EE local attachment points (centered cube)
    E_local = np.array([
        [-b2, -b2,  b2],
        [-b2,  b2,  b2],
        [ b2,  b2,  b2],
        [ b2, -b2,  b2],
        [-b2, -b2, -b2],
        [-b2,  b2, -b2],
        [ b2,  b2, -b2],
        [ b2, -b2, -b2],
    ])
    return motors, E_local
