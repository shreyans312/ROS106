from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(package='cdpm_control', executable='ik_node', output='screen'),
    ])
